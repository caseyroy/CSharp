using System;
using Microsoft.AspNetCore.Mvc;



namespace PortfolioOne.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet]
        [Route("")]
        public string Index()
        {
            return "This is my Index, there are many like it, but this one is mine,";
        }
        [HttpGet("projects")]
        public string Projects()
        {
            return "These are my Projects, there are many like them, but these ones are mine.";
        }
        [HttpGet("contact")]
        public string Contact()
        {
            return "This is my Contact, there are none like it, for this one is mine.";
        }
    }

}

